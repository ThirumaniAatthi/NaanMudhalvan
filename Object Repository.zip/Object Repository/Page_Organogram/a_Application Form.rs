<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Application Form</name>
   <tag></tag>
   <elementGuidId>94e26330-f89f-4947-b2b3-d0145c06863c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//nav[@id='navbar']/ul/li[4]/ul/li[3]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Application Form&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>f1fcbb89-01f3-44f1-89b7-578d74c70866</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/application-form</value>
      <webElementGuid>bd4b96e4-50d8-4927-ba0f-e7beb8603c70</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Application Form</value>
      <webElementGuid>c890fc6c-1b7d-40f4-96df-0eda40c4d397</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;navbar&quot;)/ul[@class=&quot;top__menu ms-auto me-auto&quot;]/li[@class=&quot;dropdown&quot;]/ul[1]/li[3]/a[1]</value>
      <webElementGuid>5632dbb1-2b81-48a4-b88a-c3d5847a472b</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//nav[@id='navbar']/ul/li[4]/ul/li[3]/a</value>
      <webElementGuid>7b37d780-8d18-45f6-a155-47700725ee55</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Application Form')]</value>
      <webElementGuid>3403f8a2-c28b-4479-9d48-4032469e8263</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Courses Offered'])[1]/following::a[1]</value>
      <webElementGuid>1c1a5607-70fb-48d4-9518-1ae7d3dfab5a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Admission'])[2]/following::a[2]</value>
      <webElementGuid>eddfc0dc-c758-4857-a66d-395bd137fb81</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Admission Policy'])[1]/preceding::a[1]</value>
      <webElementGuid>a01cbb94-f611-4e7f-a71e-7d9afe7f44a8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Online Fee Payment'])[1]/preceding::a[2]</value>
      <webElementGuid>6615a7dd-bab4-4be7-a2c4-56a1cc084ea5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Application Form']/parent::*</value>
      <webElementGuid>a1e99666-faf1-4a65-bfe2-091358055d98</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/application-form')]</value>
      <webElementGuid>45f7af83-3774-4b81-9ca4-ab7e8b167904</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[4]/ul/li[3]/a</value>
      <webElementGuid>19a3f226-fdb6-4c97-98b0-0c6e1cd665c7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/application-form' and (text() = 'Application Form' or . = 'Application Form')]</value>
      <webElementGuid>50d15b09-c3ea-42c0-9b84-911ffbb6de85</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
