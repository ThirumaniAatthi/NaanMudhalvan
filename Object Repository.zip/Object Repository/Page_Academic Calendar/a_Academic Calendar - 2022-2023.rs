<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Academic Calendar - 2022-2023</name>
   <tag></tag>
   <elementGuidId>ffdb93c3-e77b-4cfe-b1fe-41e2c4fd153d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/p[2]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>a[title=&quot;Academic Calendar - 2022-2023&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Academic Calendar - 2022-2023&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>c64b193c-be49-4672-b9ba-9c7e45bc937e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://nscollege.org.in/files_list/nscas/fm/WEBSITE/Academics/Academic Calendar/2022-2023.pdf</value>
      <webElementGuid>607e126a-3ebd-4466-838a-45498fde8632</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>Academic Calendar - 2022-2023</value>
      <webElementGuid>9f24947a-967d-46e0-829a-38a4c23dba23</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>target</name>
      <type>Main</type>
      <value>_blank</value>
      <webElementGuid>5be637af-ada3-406e-b171-5cf156c90fdb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Academic Calendar - 2022-2023</value>
      <webElementGuid>6378cb1e-1bbe-40b1-952c-e7f676c426b8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/section[2]/div[@class=&quot;container com-sp pad-bot-70 pg-inn ps_min_height px-5&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[1]/p[2]/a[1]</value>
      <webElementGuid>6e888f0b-3d7e-414d-9ddb-742484112c67</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/p[2]/a</value>
      <webElementGuid>2d6290b6-ddbd-4bbc-b42c-fa89d238c7d5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Academic Calendar - 2022-2023')]</value>
      <webElementGuid>85afe025-c118-45b9-81fe-972bc77c6f03</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Academic Calendar - 2023-2024'])[1]/following::a[1]</value>
      <webElementGuid>7dc8f5e3-a12d-4bd0-aa67-07c3913cde42</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='ACADEMIC CALENDAR'])[1]/following::a[2]</value>
      <webElementGuid>a168e8e3-c40e-49bd-bd45-cdcc2bf9a13e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Academic Calendar - 2021-2022'])[1]/preceding::a[1]</value>
      <webElementGuid>6cc2165a-660e-4bc1-bb4b-6b4bef4c94d7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Academic Calendar - 2020-2021'])[1]/preceding::a[2]</value>
      <webElementGuid>98287d5f-ff56-40b3-9514-06f40bc80f6f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Academic Calendar - 2022-2023']/parent::*</value>
      <webElementGuid>864e19be-e3ec-41f1-a950-84c329969d90</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://nscollege.org.in/files_list/nscas/fm/WEBSITE/Academics/Academic Calendar/2022-2023.pdf')]</value>
      <webElementGuid>41b9a1a6-940d-4803-a93d-785ea3bd48a5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p[2]/a</value>
      <webElementGuid>ed49c2db-f654-43fa-9a44-ac5c32d4a35b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://nscollege.org.in/files_list/nscas/fm/WEBSITE/Academics/Academic Calendar/2022-2023.pdf' and @title = 'Academic Calendar - 2022-2023' and (text() = 'Academic Calendar - 2022-2023' or . = 'Academic Calendar - 2022-2023')]</value>
      <webElementGuid>c2505d83-6fc1-4cc8-a6a5-a3b9f185399f</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
