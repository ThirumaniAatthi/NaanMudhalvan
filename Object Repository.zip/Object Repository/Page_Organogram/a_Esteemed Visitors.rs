<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Esteemed Visitors</name>
   <tag></tag>
   <elementGuidId>80e777ef-97b9-4b41-872a-6d1da4a18aff</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//nav[@id='navbar']/ul/li[2]/ul/li[9]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li:nth-of-type(9) > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Esteemed Visitors&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>26d80f0c-fcd7-4186-bfd3-0e78310a404d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/esteemed-visitors</value>
      <webElementGuid>aed97f18-41b9-4c91-8449-0b443937daad</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Esteemed Visitors</value>
      <webElementGuid>7f0e5ef3-2e9a-4ace-8a4a-ebdb972f0d2a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;navbar&quot;)/ul[@class=&quot;top__menu ms-auto me-auto&quot;]/li[@class=&quot;dropdown&quot;]/ul[1]/li[9]/a[1]</value>
      <webElementGuid>33aa09a9-28b8-4420-a57f-d489ffe2368d</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//nav[@id='navbar']/ul/li[2]/ul/li[9]/a</value>
      <webElementGuid>877e377a-19ed-49b6-95b7-cbff9cb4be5c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Esteemed Visitors')]</value>
      <webElementGuid>14424f9d-3207-48cd-932a-aa2887dfae0b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='NAAC'])[1]/following::a[1]</value>
      <webElementGuid>c623cf17-ab73-429a-adfa-3656f3440b17</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='AICTE'])[1]/following::a[2]</value>
      <webElementGuid>0adf3332-339d-4fd4-8d7d-2edaaebc0acf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Governance'])[1]/preceding::a[1]</value>
      <webElementGuid>0a12c41d-46b9-42ae-bb50-08e8e6dba206</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Our Management'])[1]/preceding::a[2]</value>
      <webElementGuid>022cf58f-725e-4172-8149-b2beaba4a60f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Esteemed Visitors']/parent::*</value>
      <webElementGuid>4a688bb6-a925-4599-b0fa-936c69b73558</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/esteemed-visitors')]</value>
      <webElementGuid>7064092e-7152-420b-9a4d-abba7c446fbd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[2]/ul/li[9]/a</value>
      <webElementGuid>e80b1209-257b-49de-a92e-cb0ef2f07ab4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/esteemed-visitors' and (text() = 'Esteemed Visitors' or . = 'Esteemed Visitors')]</value>
      <webElementGuid>015ddb44-5ba8-47da-a9fe-2df5e23863a2</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
