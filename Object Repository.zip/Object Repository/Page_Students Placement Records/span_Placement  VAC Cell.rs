<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Placement  VAC Cell</name>
   <tag></tag>
   <elementGuidId>2faaa99a-3a27-4c85-aab8-8320389f61d4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//nav[@id='navbar']/ul/li[9]/a/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Placement &amp; VAC Cell &quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>9c4f97d2-dadb-46e5-90b3-73f50cd90322</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Placement &amp; VAC Cell</value>
      <webElementGuid>414e598c-d5e4-4e23-8695-1e45d1e48e5c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;navbar&quot;)/ul[@class=&quot;top__menu ms-auto me-auto&quot;]/li[@class=&quot;dropdown&quot;]/a[@class=&quot;first_link&quot;]/span[1]</value>
      <webElementGuid>d9473cbe-4f70-46e4-9304-8c184c775de9</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//nav[@id='navbar']/ul/li[9]/a/span</value>
      <webElementGuid>eecd1b67-de81-4886-bd35-bb4e698d0234</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Clubs'])[1]/following::span[1]</value>
      <webElementGuid>1b81bd40-be6c-49fe-95a1-0e27b0b455d3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='EDC cum Earn while you Learn'])[1]/following::span[1]</value>
      <webElementGuid>642299eb-42f0-4aca-bd71-952a4952b43e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='About Placement'])[1]/preceding::span[1]</value>
      <webElementGuid>5379dbbf-eec6-4e08-ade8-7ab3b3da4f07</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Placement &amp; VAC Cell']/parent::*</value>
      <webElementGuid>39303b2e-7cca-4cd8-8bf3-6d26de361d1e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[9]/a/span</value>
      <webElementGuid>eeefb883-6164-4645-8ea0-b4a014d8e1c7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Placement &amp; VAC Cell' or . = 'Placement &amp; VAC Cell')]</value>
      <webElementGuid>a3970810-0dfe-4f5c-9e20-dc5f14567caf</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
