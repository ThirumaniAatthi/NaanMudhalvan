<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_AQAR 2022 - 2023</name>
   <tag></tag>
   <elementGuidId>84525dee-92d0-41a5-87b5-2b592e6337a9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/div[2]/a/button</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>button.button-arounder</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=button[name=&quot;AQAR 2022 - 2023&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>2cd27484-8dc5-465c-b8b8-8cdff41dc2a0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>button-arounder</value>
      <webElementGuid>03ead8db-e0f2-4bb9-adb8-22dad909a1ec</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>AQAR 2022 - 2023
 </value>
      <webElementGuid>3eae5dff-c5f1-46ad-9dc2-e20a1cd57b0f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/section[2]/div[@class=&quot;container com-sp pad-bot-70 pg-inn ps_min_height px-5&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[1]/div[@class=&quot;buttons-container&quot;]/a[1]/button[@class=&quot;button-arounder&quot;]</value>
      <webElementGuid>9fd7e673-4550-4812-a040-2b25f674bf5d</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/div[2]/a/button</value>
      <webElementGuid>7b6ce0e0-d28f-4bf1-a976-edca2d475f22</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='AQAR'])[3]/following::button[1]</value>
      <webElementGuid>77c34bab-5785-483b-869c-0fa13a9e9d37</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='AQAR 2021 - 2022'])[1]/preceding::button[1]</value>
      <webElementGuid>ca922f87-aa29-4e64-9d8a-1a38a189f100</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='AQAR 2020 - 2021'])[1]/preceding::button[2]</value>
      <webElementGuid>68d40a8e-2092-4606-aeda-78912b76b636</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='AQAR 2022 - 2023']/parent::*</value>
      <webElementGuid>cf5f9c1e-9c78-4b4f-8a56-31989393c194</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//button</value>
      <webElementGuid>d811c380-b981-43d2-b9d5-a970496da8a3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//button[(text() = 'AQAR 2022 - 2023
 ' or . = 'AQAR 2022 - 2023
 ')]</value>
      <webElementGuid>6b3154df-bf0f-4c0e-8341-92f313893e20</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
