<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Chronology of Events</name>
   <tag></tag>
   <elementGuidId>0021c976-a37b-4333-9742-014034ccf087</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//nav[@id='navbar']/ul/li[2]/ul/li[3]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li.dropdown > ul > li:nth-of-type(3) > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Chronology of Events&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>e52f5a60-e2aa-4df2-a3e1-af5310b8cfab</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/chronology-of-events</value>
      <webElementGuid>f77a94d9-6d9a-46b1-8c5d-a8ea5b97e25b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Chronology of Events</value>
      <webElementGuid>e03936c5-dc42-4211-bfcd-48a3ce335898</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;navbar&quot;)/ul[@class=&quot;top__menu ms-auto me-auto&quot;]/li[@class=&quot;dropdown&quot;]/ul[1]/li[3]/a[1]</value>
      <webElementGuid>28de6eef-6362-4f33-9bf8-9431d750be88</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//nav[@id='navbar']/ul/li[2]/ul/li[3]/a</value>
      <webElementGuid>11f34a87-7bb6-4564-afbf-2d632046e5ba</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Chronology of Events')]</value>
      <webElementGuid>b9351188-dc61-4c4a-ac63-14f11fca7f61</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Vision and Mission'])[1]/following::a[1]</value>
      <webElementGuid>3595035f-c899-43ea-8c04-0d55e7665a75</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Profile of the College'])[1]/preceding::a[1]</value>
      <webElementGuid>4fdc55e9-34a6-4cb1-8c1d-479bca913c54</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Official Logo'])[1]/preceding::a[2]</value>
      <webElementGuid>62de43b8-b717-4338-b553-b6fe31108021</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Chronology of Events']/parent::*</value>
      <webElementGuid>ed1b4fab-8a8d-4870-a9a4-afc6d25dbae4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/chronology-of-events')]</value>
      <webElementGuid>9db76c0a-80f2-45bb-9e95-a1c0e89dac23</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[2]/ul/li[3]/a</value>
      <webElementGuid>49807a37-9a3d-4501-b66f-779096af6966</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/chronology-of-events' and (text() = 'Chronology of Events' or . = 'Chronology of Events')]</value>
      <webElementGuid>ddb26712-99fa-4264-b572-022d28a08437</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
