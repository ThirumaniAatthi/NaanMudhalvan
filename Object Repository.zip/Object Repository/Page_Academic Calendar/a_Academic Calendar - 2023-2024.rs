<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Academic Calendar - 2023-2024</name>
   <tag></tag>
   <elementGuidId>c7675a0a-ca98-4df0-a6e5-9483ab00230f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/p/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>a[title=&quot;Academic Calendar - 2023-2024&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Academic Calendar - 2023-2024&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>90bb7def-d596-44a7-a88a-e1312f63b63f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://nscollege.org.in/files_list/nscas/fm/WEBSITE/Academics/Academic Calendar/2023-2024.pdf</value>
      <webElementGuid>6a387e24-a3c7-48a4-881c-731dd30997fb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>Academic Calendar - 2023-2024</value>
      <webElementGuid>b15e86e0-1cfe-49ab-8f2a-09eaf17fee18</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>target</name>
      <type>Main</type>
      <value>_blank</value>
      <webElementGuid>04553564-6c0b-4d3e-a9d0-ad340c31daeb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Academic Calendar - 2023-2024</value>
      <webElementGuid>b51372e4-5f43-449e-8be6-a3c44bf83e0f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/section[2]/div[@class=&quot;container com-sp pad-bot-70 pg-inn ps_min_height px-5&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[1]/p[1]/a[1]</value>
      <webElementGuid>66f0ef25-b6ed-4933-abe3-d0078586afd8</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/p/a</value>
      <webElementGuid>c75cfed2-279a-4db2-9c08-d0433f564f34</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Academic Calendar - 2023-2024')]</value>
      <webElementGuid>af6bcd71-c045-408b-bfa8-a408d06f5d62</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='ACADEMIC CALENDAR'])[1]/following::a[1]</value>
      <webElementGuid>997b3a02-a571-45b8-abda-2f51b87f2b71</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Gallery'])[1]/following::a[3]</value>
      <webElementGuid>02fe7bf7-3a0d-4711-b943-202aa407bb3e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Academic Calendar - 2022-2023'])[1]/preceding::a[1]</value>
      <webElementGuid>29749ff5-6185-46a6-8194-7b71bac87b60</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Academic Calendar - 2021-2022'])[1]/preceding::a[2]</value>
      <webElementGuid>8112a18e-2f83-4308-9094-828ce45790c8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Academic Calendar - 2023-2024']/parent::*</value>
      <webElementGuid>3b089088-5a9e-433d-b8ff-59e2130f25d4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://nscollege.org.in/files_list/nscas/fm/WEBSITE/Academics/Academic Calendar/2023-2024.pdf')]</value>
      <webElementGuid>838d50ff-f6d4-4805-b6e6-2e6545f58670</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p/a</value>
      <webElementGuid>20eede01-d9bd-4dc6-aec4-e297f256793e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://nscollege.org.in/files_list/nscas/fm/WEBSITE/Academics/Academic Calendar/2023-2024.pdf' and @title = 'Academic Calendar - 2023-2024' and (text() = 'Academic Calendar - 2023-2024' or . = 'Academic Calendar - 2023-2024')]</value>
      <webElementGuid>9c4e546a-fcd7-4c04-9181-a853b2a6ac4f</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
