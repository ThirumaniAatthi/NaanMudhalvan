<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Gallery_nav-link first_link</name>
   <tag></tag>
   <elementGuidId>3f0bca71-d21b-4b3f-8a99-11f36ab7cf79</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//nav[@id='navbar']/ul/li[10]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li:nth-of-type(10) > a.nav-link.first_link</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>li:nth-child(10) > .nav-link</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>1c0b4e5d-d386-4ab8-8ce9-09f15da09a6f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>nav-link first_link</value>
      <webElementGuid>bf3d115a-2405-4e15-954e-1c1d0faf1c22</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;navbar&quot;)/ul[@class=&quot;top__menu ms-auto me-auto&quot;]/li[10]/a[@class=&quot;nav-link first_link&quot;]</value>
      <webElementGuid>adaef54a-51a8-4857-a61f-91fa914517ec</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//nav[@id='navbar']/ul/li[10]/a</value>
      <webElementGuid>354b82c8-8ba9-4511-9b1b-eab1bc5d87d3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Gallery'])[1]/following::a[1]</value>
      <webElementGuid>6daea28b-937e-4cbb-87d1-9d510da52d38</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Annual Report'])[1]/following::a[2]</value>
      <webElementGuid>3f58bc85-cc38-4ece-ab62-0c9dec1d7bde</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='HALL TICKET'])[1]/preceding::a[2]</value>
      <webElementGuid>36784df7-885c-4362-aa66-7869df376e53</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Contact'])[2]/preceding::a[2]</value>
      <webElementGuid>3d18027d-56ef-430b-b62d-42a8bddb847c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[10]/a</value>
      <webElementGuid>269586d8-d4d6-489e-9828-5a7dbc084ec5</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
