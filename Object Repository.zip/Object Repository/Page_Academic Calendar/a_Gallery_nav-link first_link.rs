<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Gallery_nav-link first_link</name>
   <tag></tag>
   <elementGuidId>963c4b04-6f46-4ecd-a7ac-7dd7dc00b9fb</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//nav[@id='navbar']/ul/li[10]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li:nth-of-type(10) > a.nav-link.first_link</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>li:nth-child(10) > .nav-link</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>dcd59d06-775e-4504-9eb9-1febb7c5d0b1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>nav-link first_link</value>
      <webElementGuid>d4d5dba3-ec63-4a90-b195-2c0f6d7a6e30</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;navbar&quot;)/ul[@class=&quot;top__menu ms-auto me-auto&quot;]/li[10]/a[@class=&quot;nav-link first_link&quot;]</value>
      <webElementGuid>7b001db1-7a54-4442-aca1-d4d39be2f825</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//nav[@id='navbar']/ul/li[10]/a</value>
      <webElementGuid>da957d3a-e122-4e73-8225-41911e318bc4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Gallery'])[1]/following::a[1]</value>
      <webElementGuid>b770b320-523f-4152-a9d8-32f28a362c43</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Annual Report'])[1]/following::a[2]</value>
      <webElementGuid>e44225f8-5423-4674-89f3-0b2a33af45a0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='ACADEMIC CALENDAR'])[1]/preceding::a[2]</value>
      <webElementGuid>b1bc888f-93dd-43c6-8880-8f4a0720d9e3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Academic Calendar - 2023-2024'])[1]/preceding::a[2]</value>
      <webElementGuid>34937248-fa8c-4178-9b3e-9cc9e4cc28d0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[10]/a</value>
      <webElementGuid>893a4456-60a3-4c77-9eac-77d991afd6b9</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
