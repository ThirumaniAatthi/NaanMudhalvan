<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Placement  VAC Cell</name>
   <tag></tag>
   <elementGuidId>8b266ab9-7b7a-4b88-8887-d5be0ec7cac0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//nav[@id='navbar']/ul/li[9]/a/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Placement &amp; VAC Cell &quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>6d1d7e7c-0027-4114-8b5b-e1eca222d24a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Placement &amp; VAC Cell</value>
      <webElementGuid>ccf5a69f-3d43-45c4-a5c1-9a3aeadf8afa</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;navbar&quot;)/ul[@class=&quot;top__menu ms-auto me-auto&quot;]/li[@class=&quot;dropdown&quot;]/a[@class=&quot;first_link&quot;]/span[1]</value>
      <webElementGuid>20c114d7-b8e6-4763-80ad-defe3932dc4a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//nav[@id='navbar']/ul/li[9]/a/span</value>
      <webElementGuid>aa0cf0f1-7a3d-4217-abfa-0d543f821e69</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Clubs'])[1]/following::span[1]</value>
      <webElementGuid>883ec3ff-3bc8-49ea-a6d4-ed28aa7a1116</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='EDC cum Earn while you Learn'])[1]/following::span[1]</value>
      <webElementGuid>3fc85c5f-ac8e-4a5f-89d1-c92c7ebdae90</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='About Placement'])[1]/preceding::span[1]</value>
      <webElementGuid>c1afc954-f6d7-4015-9316-bf0b3c3ba7c0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Placement &amp; VAC Cell']/parent::*</value>
      <webElementGuid>43d38987-bb1f-4d0a-8a72-912093031c47</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[9]/a/span</value>
      <webElementGuid>41c493b4-abab-4c1f-9f94-fe0230ddc0c8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Placement &amp; VAC Cell' or . = 'Placement &amp; VAC Cell')]</value>
      <webElementGuid>d9d2bcb2-a7a4-4283-8fe5-00c7bf07dd4c</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
