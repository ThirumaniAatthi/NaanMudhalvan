<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Student Grievances</name>
   <tag></tag>
   <elementGuidId>3add5749-ac34-4d89-9da3-27fdb09973e4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//ul[@id='rc-menu-uuid-89993-8-131-popup']/li[5]/span/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li.ant-menu-item.ant-menu-item-active.ant-menu-item-only-child > span.ant-menu-title-content > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=menuitem[name=&quot;Student Grievances&quot;i] >> internal:role=link</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>e6625784-45a7-4889-be07-4ddc417499c1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/student-grievances</value>
      <webElementGuid>7f7af7a6-86cd-4923-a637-52650f4fcccf</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Student Grievances</value>
      <webElementGuid>9373b225-621f-4457-bb37-a6b64071d0c8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;rc-menu-uuid-89993-8-131-popup&quot;)/li[@class=&quot;ant-menu-item ant-menu-item-active ant-menu-item-only-child&quot;]/span[@class=&quot;ant-menu-title-content&quot;]/a[1]</value>
      <webElementGuid>f478a69a-efbe-4377-ae99-3c181225aa5f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//ul[@id='rc-menu-uuid-89993-8-131-popup']/li[5]/span/a</value>
      <webElementGuid>22fa5990-f290-4380-9337-fde24fd02266</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>(//a[contains(text(),'Student Grievances')])[2]</value>
      <webElementGuid>05e518c6-a2f7-4f1f-9972-c25a6966f356</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Gallery'])[2]/following::a[1]</value>
      <webElementGuid>9850f163-d7ea-494a-8a7c-f629ca58066b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Services'])[1]/following::a[2]</value>
      <webElementGuid>34a02202-8afd-4f18-8565-70d2115a92e9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, '/student-grievances')])[2]</value>
      <webElementGuid>22d447ed-8920-4685-98bd-97115f087266</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[5]/span/a</value>
      <webElementGuid>0a50b0f0-ba63-4a57-a1cd-6aee1ca05e48</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/student-grievances' and (text() = 'Student Grievances' or . = 'Student Grievances')]</value>
      <webElementGuid>5b674d50-7971-482a-a4ec-268f39d5fb6c</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
