<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Orientation  FIP</name>
   <tag></tag>
   <elementGuidId>f6fb307d-76d5-4d39-a24d-138efc1ab859</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//nav[@id='navbar']/ul/li[7]/ul/li[13]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li:nth-of-type(13) > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Orientation / FIP&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>4875f027-0051-4907-9eff-efe4015ee66a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/orientationfip</value>
      <webElementGuid>992aef03-c2c1-48a0-bc60-4bae6ab943c8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Orientation / FIP</value>
      <webElementGuid>1a4e50f4-4e76-44c0-af53-f4b79f73c3cc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;navbar&quot;)/ul[@class=&quot;top__menu ms-auto me-auto&quot;]/li[@class=&quot;dropdown&quot;]/ul[1]/li[13]/a[1]</value>
      <webElementGuid>9f2edad3-31e2-420f-b695-b2f6618f5c85</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//nav[@id='navbar']/ul/li[7]/ul/li[13]/a</value>
      <webElementGuid>1af40aeb-796b-479e-81bd-1943026eb595</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Orientation / FIP')]</value>
      <webElementGuid>f505efdc-531b-4c4b-92e3-ed85a22558ee</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Annual Reports'])[1]/following::a[1]</value>
      <webElementGuid>b4554ed0-883f-440f-b07b-5b567dc45f0d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Feedback'])[1]/following::a[2]</value>
      <webElementGuid>34ebb4df-1524-448b-9627-740e101809b7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='FDP / PDP'])[1]/preceding::a[1]</value>
      <webElementGuid>fa81c604-3f51-41a1-bf30-de94a6b803ab</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Autonomy'])[1]/preceding::a[2]</value>
      <webElementGuid>98eb9ad5-9c83-487a-add5-4d5e69e6bf10</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Orientation / FIP']/parent::*</value>
      <webElementGuid>600bd1cd-59bd-43d5-a28f-e64d6433c2ed</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/orientationfip')]</value>
      <webElementGuid>38d7444b-fc84-4a8a-b842-7a1d862491c2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[13]/a</value>
      <webElementGuid>d27a1b0c-8ae1-4595-a7e7-2765e28d913a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/orientationfip' and (text() = 'Orientation / FIP' or . = 'Orientation / FIP')]</value>
      <webElementGuid>ace7935e-2012-49ac-aa75-6a959710aa54</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
