<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Orientation  FIP</name>
   <tag></tag>
   <elementGuidId>e1b062fa-5ed5-4670-bca0-2d62b0292920</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//nav[@id='navbar']/ul/li[7]/ul/li[13]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li:nth-of-type(13) > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Orientation / FIP&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>c7fdec3b-2e15-4bfb-a772-f919bd365df7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/orientationfip</value>
      <webElementGuid>40ac565e-29ee-4a8f-910d-9a8e461f52e1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Orientation / FIP</value>
      <webElementGuid>84781bec-6c50-4c1c-926f-7e9e92261c67</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;navbar&quot;)/ul[@class=&quot;top__menu ms-auto me-auto&quot;]/li[@class=&quot;dropdown&quot;]/ul[1]/li[13]/a[1]</value>
      <webElementGuid>aaa3c516-9dc6-4dd9-8072-5f37f2eae2d3</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//nav[@id='navbar']/ul/li[7]/ul/li[13]/a</value>
      <webElementGuid>7efeb444-66d9-4566-a1d6-5ebc8504924a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Orientation / FIP')]</value>
      <webElementGuid>1d98ee23-b38e-488f-a8ba-2e9fbd6de68a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Annual Reports'])[1]/following::a[1]</value>
      <webElementGuid>75b4a06f-6190-4128-bc19-28b22a03de49</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Feedback'])[1]/following::a[2]</value>
      <webElementGuid>77262a69-7d33-4277-b899-2de93a92b189</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='FDP / PDP'])[1]/preceding::a[1]</value>
      <webElementGuid>7eca1797-8ae3-43fd-a905-d2d38702b0f0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Autonomy'])[1]/preceding::a[2]</value>
      <webElementGuid>e51b861f-14f7-4a90-8659-25de1ffc234c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Orientation / FIP']/parent::*</value>
      <webElementGuid>3e454e75-bc5b-4aff-8103-757d76e75d3d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/orientationfip')]</value>
      <webElementGuid>52eb00cf-2c09-4408-805a-dcfca58c4186</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[13]/a</value>
      <webElementGuid>5c22bc47-0be6-44d4-8400-59378514a8c3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/orientationfip' and (text() = 'Orientation / FIP' or . = 'Orientation / FIP')]</value>
      <webElementGuid>9953a09c-26b7-4e69-82f7-9fc3d9b6e053</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
