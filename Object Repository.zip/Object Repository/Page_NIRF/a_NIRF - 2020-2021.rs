<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_NIRF - 2020-2021</name>
   <tag></tag>
   <elementGuidId>75cad934-f52b-41c4-b35b-a1bb6c032cf3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/p[3]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>a[title=&quot;NIRF - 2020-2021&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;NIRF - 2020-2021&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>b1a2acae-9e3f-4e8e-a92e-082345528e1f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://nscollege.org.in/files_list/nscas/fm/WEBSITE/IQAC/NIRF/NIRF-2020-2021.pdf</value>
      <webElementGuid>09b4738f-789f-4f30-8e31-942b7f42a3ba</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>NIRF - 2020-2021</value>
      <webElementGuid>bd5b16ee-64f1-480a-a4ea-3a2b2cca64af</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>NIRF - 2020-2021</value>
      <webElementGuid>0a0b571d-d1b4-4fc2-95aa-bc9c5fa4d551</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/section[2]/div[@class=&quot;container com-sp pad-bot-70 pg-inn ps_min_height px-5&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[1]/p[3]/a[1]</value>
      <webElementGuid>40363ac1-8f02-459b-9bcd-54a68a6aa378</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/p[3]/a</value>
      <webElementGuid>371b5d85-0a5b-4d5c-a8b3-4b31ec58220c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'NIRF - 2020-2021')]</value>
      <webElementGuid>8412a3fa-cc64-46e4-ba74-62ece5095db4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='NIRF - 2021-2022'])[1]/following::a[1]</value>
      <webElementGuid>952ef836-4851-4c6f-a770-22859a0d033b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='NIRF - 2022-2023'])[1]/following::a[2]</value>
      <webElementGuid>d813e2c5-f790-4a5f-9b83-251c4b863951</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='NIRF - 2018-2019'])[1]/preceding::a[1]</value>
      <webElementGuid>7cf753c9-3288-4f27-8bc6-5d2dc2192d3a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Contact'])[2]/preceding::a[2]</value>
      <webElementGuid>a9280115-6d47-471e-86c9-1075f3702949</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='NIRF - 2020-2021']/parent::*</value>
      <webElementGuid>4d4f9d72-9684-4b7d-beef-aba6930968cd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://nscollege.org.in/files_list/nscas/fm/WEBSITE/IQAC/NIRF/NIRF-2020-2021.pdf')]</value>
      <webElementGuid>63bcb73e-35f2-4765-9f08-186b01f4fc0c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p[3]/a</value>
      <webElementGuid>1cb62bc9-5de2-44a5-92e8-6b29653bde16</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://nscollege.org.in/files_list/nscas/fm/WEBSITE/IQAC/NIRF/NIRF-2020-2021.pdf' and @title = 'NIRF - 2020-2021' and (text() = 'NIRF - 2020-2021' or . = 'NIRF - 2020-2021')]</value>
      <webElementGuid>713a3b44-918a-496b-800c-f659102cbc6a</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
