<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_IQAC-Annual Report 2023-2024</name>
   <tag></tag>
   <elementGuidId>27f3af3f-5193-4ebd-8a6a-03fa53840030</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/p/span/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>a[title=&quot;IQAC-Annual Report 2023-2024&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;IQAC-Annual Report 2023-2024&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>3c9993c4-904c-4db8-b926-5cd32de21868</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://nscollege.org.in/files_list/nscas/fm/WEBSITE/IQAC/IQAC Annual Report/IQAC-AnnualReport-2023-2024.pdf</value>
      <webElementGuid>2b45c6db-503a-4f19-a74e-5eeec7fa9d78</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>IQAC-Annual Report 2023-2024</value>
      <webElementGuid>24507f03-97f7-4dbb-98b5-617a39635d6b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>target</name>
      <type>Main</type>
      <value>_blank</value>
      <webElementGuid>cf369c59-a48e-452f-8506-0cd58315bc05</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>IQAC-Annual Report 2023-2024</value>
      <webElementGuid>fa9d04bc-fa62-4593-855d-b94408f2f8bc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/section[2]/div[@class=&quot;container com-sp pad-bot-70 pg-inn ps_min_height px-5&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[1]/p[1]/span[1]/a[1]</value>
      <webElementGuid>5d4d8c30-2127-45db-a6de-bf418460bcb3</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/p/span/a</value>
      <webElementGuid>d021dfbb-203e-41b5-907a-d7f370dfd981</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'IQAC-Annual Report 2023-2024')]</value>
      <webElementGuid>eb887797-14fc-42b2-8b1f-f9a8a6d93579</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='IQAC ANNUAL REPORTS'])[1]/following::a[1]</value>
      <webElementGuid>72e1d2b0-0be7-4805-854c-05754e97a0c9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Gallery'])[1]/following::a[3]</value>
      <webElementGuid>3ba07389-9868-4beb-8268-ededef8ff669</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='IQAC-Annual Report 2022-2023'])[1]/preceding::a[1]</value>
      <webElementGuid>1b395bbb-496f-4dd6-b30e-8b8be8a64719</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='IQAC-Annual Report 2020-2022'])[1]/preceding::a[2]</value>
      <webElementGuid>fdd8cf72-3826-43fd-95df-48571c3435a0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='IQAC-Annual Report 2023-2024']/parent::*</value>
      <webElementGuid>14e90903-7239-4caf-a42f-4aef33d1c7d5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://nscollege.org.in/files_list/nscas/fm/WEBSITE/IQAC/IQAC Annual Report/IQAC-AnnualReport-2023-2024.pdf')]</value>
      <webElementGuid>0f9d3cd3-3e6e-406a-90ff-d281a42e3008</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//span/a</value>
      <webElementGuid>34300347-56bb-40a9-854d-2e157a7447a5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://nscollege.org.in/files_list/nscas/fm/WEBSITE/IQAC/IQAC Annual Report/IQAC-AnnualReport-2023-2024.pdf' and @title = 'IQAC-Annual Report 2023-2024' and (text() = 'IQAC-Annual Report 2023-2024' or . = 'IQAC-Annual Report 2023-2024')]</value>
      <webElementGuid>8744e289-acca-41e4-ab18-7631f180a582</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
