<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Academic Calendar - 2018-2019</name>
   <tag></tag>
   <elementGuidId>af34727c-ba01-43bb-9d46-59174a3ece5b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/p[6]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>a[title=&quot;Academic Calendar - 2018-2019&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Academic Calendar - 2018-2019&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>616a3458-6270-44ad-9e74-99cf6a8260b5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://nscollege.org.in/files_list/nscas/fm/WEBSITE/Academics/Academic Calendar/2018-2019.pdf</value>
      <webElementGuid>0ef5b981-b9e1-4ff7-a8ed-5907ce696e59</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>Academic Calendar - 2018-2019</value>
      <webElementGuid>89261daf-63e4-4a01-ab88-4f834fe01eac</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>target</name>
      <type>Main</type>
      <value>_blank</value>
      <webElementGuid>27abc878-9ba2-4f91-bbca-a1acf0b4f052</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Academic Calendar - 2018-2019</value>
      <webElementGuid>2e83ba6e-8cae-40ec-82e6-79491d4be57c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/section[2]/div[@class=&quot;container com-sp pad-bot-70 pg-inn ps_min_height px-5&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[1]/p[6]/a[1]</value>
      <webElementGuid>a4433472-5033-40ee-b59d-cc6a6af3d129</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/p[6]/a</value>
      <webElementGuid>16bfda7f-391b-4de2-9073-fe63a5686d95</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Academic Calendar - 2018-2019')]</value>
      <webElementGuid>cc734c62-b4e8-4e89-b786-e4d3b59b0a9e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Academic Calendar - 2019-2020'])[1]/following::a[1]</value>
      <webElementGuid>fb1ce7b3-99b8-47de-a9ed-5ab182128b47</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Academic Calendar - 2020-2021'])[1]/following::a[2]</value>
      <webElementGuid>56a93ae6-8bcf-4167-8ff9-48c302821f97</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Contact'])[2]/preceding::a[1]</value>
      <webElementGuid>9832e1d2-78e7-409e-87dd-27e8416023a1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='principal@nscollege.org.in'])[1]/preceding::a[6]</value>
      <webElementGuid>8e575ad0-9da4-4d09-b1cf-2cd4c4aafc80</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Academic Calendar - 2018-2019']/parent::*</value>
      <webElementGuid>9f73cf74-0f4e-434d-be9f-e4da3a7fafa6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://nscollege.org.in/files_list/nscas/fm/WEBSITE/Academics/Academic Calendar/2018-2019.pdf')]</value>
      <webElementGuid>2b6c3632-9d4b-43d9-8802-a069261d4e52</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p[6]/a</value>
      <webElementGuid>4fe152bf-7a8b-4c1e-844f-94764ec17bde</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://nscollege.org.in/files_list/nscas/fm/WEBSITE/Academics/Academic Calendar/2018-2019.pdf' and @title = 'Academic Calendar - 2018-2019' and (text() = 'Academic Calendar - 2018-2019' or . = 'Academic Calendar - 2018-2019')]</value>
      <webElementGuid>3ab8dbb1-b88c-4fc7-9ff6-e7073d6e81aa</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
