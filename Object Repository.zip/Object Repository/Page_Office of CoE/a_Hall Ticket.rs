<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Hall Ticket</name>
   <tag></tag>
   <elementGuidId>0513c7f0-c52b-4037-97b4-e5399b2def0b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//ul[@id='rc-menu-uuid-89993-4-51-popup']/li/span/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#rc-menu-uuid-89993-4-51-popup > li.ant-menu-item.ant-menu-item-active.ant-menu-item-only-child > span.ant-menu-title-content > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Hall Ticket&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>7ab81600-1d1c-42cc-b0c0-9608d8d42ceb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/hall-ticket</value>
      <webElementGuid>3c8b39e3-8991-4890-a2e6-f7438eb28f61</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Hall Ticket</value>
      <webElementGuid>d91550d8-6ac3-42ed-9f35-0a58959e6c9b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;rc-menu-uuid-89993-4-51-popup&quot;)/li[@class=&quot;ant-menu-item ant-menu-item-active ant-menu-item-only-child&quot;]/span[@class=&quot;ant-menu-title-content&quot;]/a[1]</value>
      <webElementGuid>892324e8-5c8f-420a-a63b-80371b8aeb94</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//ul[@id='rc-menu-uuid-89993-4-51-popup']/li/span/a</value>
      <webElementGuid>4d9dbfb5-7530-4ae9-b151-116f9c91527b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>(//a[contains(text(),'Hall Ticket')])[2]</value>
      <webElementGuid>a2dbe41e-8796-4cb2-8abd-e799b528fe12</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Examinations - Exam'])[2]/following::a[1]</value>
      <webElementGuid>852c5ff6-5a05-43ea-bb9f-746835e2f02c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Office of CoE'])[3]/following::a[1]</value>
      <webElementGuid>2ba183f1-a60b-40ee-8a32-efe6e60c1f34</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Result'])[2]/preceding::a[1]</value>
      <webElementGuid>ce6b7777-bada-4772-8989-e2c8e0c41ece</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='CIA'])[2]/preceding::a[2]</value>
      <webElementGuid>f749ef89-5b6d-4857-9f96-0789e8579a26</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, '/hall-ticket')])[2]</value>
      <webElementGuid>604b7e3f-0756-486c-8154-64b78cc11099</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[2]/ul/li/span/a</value>
      <webElementGuid>b3dbb132-4743-469c-ba4e-956f3d06d093</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/hall-ticket' and (text() = 'Hall Ticket' or . = 'Hall Ticket')]</value>
      <webElementGuid>efb4e109-9d19-4a5b-8274-8243b64d81ad</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
