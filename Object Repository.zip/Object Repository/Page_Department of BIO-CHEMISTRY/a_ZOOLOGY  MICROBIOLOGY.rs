<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_ZOOLOGY  MICROBIOLOGY</name>
   <tag></tag>
   <elementGuidId>4b15b997-8f39-4852-aacc-3ee62e9317e9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/section[2]/div/div/div[3]/div[2]/ul/li[12]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li:nth-of-type(12) > a.fs-14</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;ZOOLOGY &amp; MICROBIOLOGY&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>0b9e109c-9a06-4391-9edc-08fab4dd2c43</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>fs-14 </value>
      <webElementGuid>159c138f-ebbe-4f73-9edd-45e8aae05197</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/department/13/zoology--microbiology</value>
      <webElementGuid>d7c3721e-46e7-4f51-aed9-8a2a327c59aa</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>ZOOLOGY &amp; MICROBIOLOGY</value>
      <webElementGuid>7f28c00e-71b2-4220-b733-b84148001d2d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/section[2]/div[@class=&quot;container-fluid com-sp pad-bot-70 pg-inn ps_min_height&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-3&quot;]/div[@class=&quot;ho-event&quot;]/ul[@class=&quot;ps__sidebar__links ps-0&quot;]/li[12]/a[@class=&quot;fs-14&quot;]</value>
      <webElementGuid>2317465a-2a1e-4681-9d94-ba5567525e87</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/section[2]/div/div/div[3]/div[2]/ul/li[12]/a</value>
      <webElementGuid>6bf8e954-65c3-4185-abcc-6449e6ead7a8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'ZOOLOGY &amp; MICROBIOLOGY')]</value>
      <webElementGuid>040bfd35-ea8b-4843-a485-b22e561e43dd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='BIO-CHEMISTRY'])[1]/following::a[1]</value>
      <webElementGuid>3f9b19ad-3664-4f61-b0b2-bc9ab848cd2a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='MATHEMATICS'])[1]/following::a[2]</value>
      <webElementGuid>4b0b330b-ba16-480f-885f-e2d22af79d63</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='COMPUTER SCIENCE'])[1]/preceding::a[1]</value>
      <webElementGuid>9284ee04-4a7e-4482-a837-1378b7d15e2b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='INFORMATION TECHNOLOGY'])[1]/preceding::a[2]</value>
      <webElementGuid>885b4311-c6c1-4dc5-9772-43a35f891870</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='ZOOLOGY &amp; MICROBIOLOGY']/parent::*</value>
      <webElementGuid>b5ffbe45-cf41-47c2-b772-436ca1cfd4a4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/department/13/zoology--microbiology')]</value>
      <webElementGuid>7cb73aab-8325-4d34-98db-878ede64296e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/ul/li[12]/a</value>
      <webElementGuid>5d274c51-fd2a-470f-87f5-9fdbde31bda9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/department/13/zoology--microbiology' and (text() = 'ZOOLOGY &amp; MICROBIOLOGY' or . = 'ZOOLOGY &amp; MICROBIOLOGY')]</value>
      <webElementGuid>7bc4a904-f498-4bc1-8f46-0b47ccc91117</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
