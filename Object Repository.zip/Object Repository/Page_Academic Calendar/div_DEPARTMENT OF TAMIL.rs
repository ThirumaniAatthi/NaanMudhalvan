<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_DEPARTMENT OF TAMIL</name>
   <tag></tag>
   <elementGuidId>4d21cff8-8e89-4a9c-93ba-aab2089f0bea</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/section[2]/div/div/div/a/div/div/div[2]/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.d-flex.justify-content-center.align-items-center</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;DEPARTMENT OF TAMIL&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>baac608b-c629-4413-9c24-007c84b45ac0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>d-flex justify-content-center align-items-center</value>
      <webElementGuid>fd405e9e-2cf6-496c-b751-cbd82699ecc9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>DEPARTMENT OF TAMIL</value>
      <webElementGuid>d478ccc8-b00d-4a1c-8147-ac29a5330384</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/section[2]/div[@class=&quot;container pg-inn ps_min_height&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;mb-4 col-md-4&quot;]/a[1]/div[@class=&quot;home-top-cour py-0&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;fw-bold text-dark col-md-8 col-8&quot;]/div[@class=&quot;d-flex justify-content-center align-items-center&quot;]</value>
      <webElementGuid>7f5b191d-9b63-403f-9cdf-84ebd763777b</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/section[2]/div/div/div/a/div/div/div[2]/div</value>
      <webElementGuid>87c7c611-f66d-49d1-856c-5d523f05e6d4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Departments'])[2]/following::div[9]</value>
      <webElementGuid>bd319a8a-c482-4729-982e-f6817d6cc2fb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Gallery'])[1]/following::div[17]</value>
      <webElementGuid>b8a56728-2caf-40ed-8078-2a3f8a95dbe4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='DEPARTMENT OF']/parent::*</value>
      <webElementGuid>cf2d6410-52e4-42ce-9475-d7a0cd823b8b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//a/div/div/div[2]/div</value>
      <webElementGuid>d7728356-808d-4631-a4be-359ccc9a8890</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'DEPARTMENT OF TAMIL' or . = 'DEPARTMENT OF TAMIL')]</value>
      <webElementGuid>1e0129d8-bfae-44ba-9d04-ddad3772fa77</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
