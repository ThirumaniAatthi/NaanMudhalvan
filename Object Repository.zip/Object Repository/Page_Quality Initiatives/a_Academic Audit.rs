<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Academic Audit</name>
   <tag></tag>
   <elementGuidId>db1c75cc-98fc-429a-8a39-97c0bf22892b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//nav[@id='navbar']/ul/li[7]/ul/li[9]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Academic Audit&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>4e8b9a8a-52f3-46c9-a313-14d0140d1020</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/academic-audit</value>
      <webElementGuid>b83443a0-3b05-49f1-952b-46e4863fbe00</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Academic Audit</value>
      <webElementGuid>970e93db-2f90-44ec-8e32-122d858b9d67</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;navbar&quot;)/ul[@class=&quot;top__menu ms-auto me-auto&quot;]/li[@class=&quot;dropdown&quot;]/ul[1]/li[9]/a[1]</value>
      <webElementGuid>359d87b0-4082-426a-bd98-207dbca15909</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//nav[@id='navbar']/ul/li[7]/ul/li[9]/a</value>
      <webElementGuid>6e9c93af-3ad2-481b-802c-6926a801997a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Academic Audit')]</value>
      <webElementGuid>fefccd11-00ef-4a62-8dc5-4c21f1822c41</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Quality Initiatives'])[2]/following::a[1]</value>
      <webElementGuid>c615bb2f-cc89-44fc-9153-bab76cdb6b93</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='NIRF'])[1]/following::a[2]</value>
      <webElementGuid>aeeb4bd5-4a8c-4ae3-9db9-a2b4eb35d446</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Strategic Plan &amp; Deployment'])[1]/preceding::a[1]</value>
      <webElementGuid>e8d2b042-6442-4fb8-b889-f33f44b4b9cd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Feedback'])[1]/preceding::a[2]</value>
      <webElementGuid>e2e8e5ee-1002-4308-b97e-7346bf06f9e9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Academic Audit']/parent::*</value>
      <webElementGuid>bc4afb09-4271-4525-b526-2baf1ca062d5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/academic-audit')]</value>
      <webElementGuid>b4eb3e48-3636-42b2-8dd7-d30f11639da1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[7]/ul/li[9]/a</value>
      <webElementGuid>2b2f4d75-eba6-408a-9e15-328d2436fb48</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/academic-audit' and (text() = 'Academic Audit' or . = 'Academic Audit')]</value>
      <webElementGuid>f54438d6-71d8-4f12-b0dd-a858f1fa09b4</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
