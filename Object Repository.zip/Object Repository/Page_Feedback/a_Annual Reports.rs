<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Annual Reports</name>
   <tag></tag>
   <elementGuidId>d823a24d-1bc1-4a3c-a498-f305f001a2c7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//nav[@id='navbar']/ul/li[7]/ul/li[12]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li:nth-of-type(12) > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Annual Reports&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>4a8ef68c-ebb8-4e41-9030-bbe007fca355</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/iqac-annual-reports</value>
      <webElementGuid>b45bc071-4216-4dbd-8a9c-27c1e407c59e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Annual Reports</value>
      <webElementGuid>d55c36c0-e0bb-477c-bf7a-96f8d8eac170</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;navbar&quot;)/ul[@class=&quot;top__menu ms-auto me-auto&quot;]/li[@class=&quot;dropdown&quot;]/ul[1]/li[12]/a[1]</value>
      <webElementGuid>be4cc45c-b5f8-4cef-8c73-1a8622177cf6</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//nav[@id='navbar']/ul/li[7]/ul/li[12]/a</value>
      <webElementGuid>bcb9ac8d-ca00-44c4-b742-c67c18e3c703</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Annual Reports')]</value>
      <webElementGuid>e666d3ce-d692-4ede-a7fd-9f0602fe8b0e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Feedback'])[2]/following::a[1]</value>
      <webElementGuid>fcca8ce4-7734-4f10-8ac8-44f83fbee05b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Strategic Plan &amp; Deployment'])[1]/following::a[2]</value>
      <webElementGuid>17fb35eb-fea0-485f-bc96-0d897bccb3a3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Orientation / FIP'])[1]/preceding::a[1]</value>
      <webElementGuid>cec628c0-66cc-4ac2-a9de-45bc9048137d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='FDP / PDP'])[1]/preceding::a[2]</value>
      <webElementGuid>ec8dc046-5cb1-4669-bf7f-2ab95fd6f18b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Annual Reports']/parent::*</value>
      <webElementGuid>6a5449fd-991c-4590-be09-17d8137f483b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/iqac-annual-reports')]</value>
      <webElementGuid>6d8c5477-35e7-4b7f-bf2f-68040761fafe</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[12]/a</value>
      <webElementGuid>66a4619b-a56a-4bd7-8c4e-6e300ad222a9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/iqac-annual-reports' and (text() = 'Annual Reports' or . = 'Annual Reports')]</value>
      <webElementGuid>0f3ed7b3-5b83-4a1d-ae81-bf0402efc26b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
