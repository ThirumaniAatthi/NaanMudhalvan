<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Dr.A.Saranya, Vice Principal</name>
   <tag></tag>
   <elementGuidId>6dd4dfe8-c96e-43b2-8a86-58c878cca677</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/table/tbody/tr[2]/td[2]/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>tr:nth-of-type(2) > td:nth-of-type(2) > span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Dr.A.Saranya, Vice Principal&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>3dc9386c-9da6-4f77-9ebe-b0ddd88de1b2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Dr.A.Saranya, Vice Principal</value>
      <webElementGuid>4e09ec74-472d-43b6-82c1-4ea0a1de9450</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/section[2]/div[@class=&quot;container com-sp pad-bot-70 pg-inn ps_min_height px-5&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[1]/table[1]/tbody[1]/tr[2]/td[2]/span[1]</value>
      <webElementGuid>1c56d7a4-a0d3-44b3-ab44-0f76a0a7e94f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/table/tbody/tr[2]/td[2]/span</value>
      <webElementGuid>8d66cd76-3277-4df0-b18c-7c08acd119c5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Director of IQAC'])[1]/following::span[1]</value>
      <webElementGuid>d2e64d6c-033e-42a5-93f6-735afd84285e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Dr.S.Chitra, Principal'])[1]/following::span[1]</value>
      <webElementGuid>66d4baf6-6dd6-4d1a-b11b-b90e76aca81b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Coordinators'])[1]/preceding::span[1]</value>
      <webElementGuid>d969ec85-aad9-4fbc-8d4a-3fc8e8c61bd2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Dr.P.Meenambigai, Head Department of Physics'])[1]/preceding::span[2]</value>
      <webElementGuid>65f711f5-8e6c-4bec-8da9-a0233f18def7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Dr.A.Saranya, Vice Principal']/parent::*</value>
      <webElementGuid>65691297-a778-40d2-9a43-86cde672942c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//tr[2]/td[2]/span</value>
      <webElementGuid>7c1a657d-cb51-47db-b360-aa5fec1051f6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Dr.A.Saranya, Vice Principal' or . = 'Dr.A.Saranya, Vice Principal')]</value>
      <webElementGuid>fb353216-3ef9-4714-bb11-d0438a20b1ea</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
