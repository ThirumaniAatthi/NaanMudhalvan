<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_BCOM-COMPUTER APPLICATION</name>
   <tag></tag>
   <elementGuidId>e5f1d029-b23f-4cb0-8acf-d471571356b9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/section[2]/div/div/div[3]/div[2]/ul/li[6]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;BCOM-COMPUTER APPLICATION&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>3b55ff80-b4aa-45b2-a880-dbe7a443db2c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>fs-14 </value>
      <webElementGuid>ea63d2e6-ccdb-418e-8503-feaeabd5dcea</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/department/6/bcom-computer-application</value>
      <webElementGuid>82194b9b-3d30-4cf0-9e39-f452f34bc23f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>BCOM-COMPUTER APPLICATION</value>
      <webElementGuid>6b9af6d8-b47b-47cd-9e48-c129dfc9fb2e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/section[2]/div[@class=&quot;container-fluid com-sp pad-bot-70 pg-inn ps_min_height&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-3&quot;]/div[@class=&quot;ho-event&quot;]/ul[@class=&quot;ps__sidebar__links ps-0&quot;]/li[6]/a[@class=&quot;fs-14&quot;]</value>
      <webElementGuid>7f79103d-1fa0-4017-91d6-a45221a0de1e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/section[2]/div/div/div[3]/div[2]/ul/li[6]/a</value>
      <webElementGuid>9ef8eebd-cd9f-4e8d-ac28-0a5821f25fc4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'BCOM-COMPUTER APPLICATION')]</value>
      <webElementGuid>19527ee2-b8f2-4be1-be4b-25f4d0183409</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='COMMERCE'])[1]/following::a[1]</value>
      <webElementGuid>6373503a-5108-4997-ab48-bea7b334ca64</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='BUSINESS ADMINSTRATION'])[1]/following::a[2]</value>
      <webElementGuid>6ae14f26-0faa-4f49-8691-7072d089458e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='COMPUTER APPLICATION'])[1]/preceding::a[1]</value>
      <webElementGuid>00ee8e58-b75a-48a8-9bab-c460f50d3e56</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='CHEMISTRY'])[1]/preceding::a[2]</value>
      <webElementGuid>fc89decd-3982-4e5d-a6ec-8ebace26b615</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='BCOM-COMPUTER APPLICATION']/parent::*</value>
      <webElementGuid>901421ac-cad4-4de9-b3ba-eb2d9f432643</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/department/6/bcom-computer-application')]</value>
      <webElementGuid>8c136434-6b28-4cfc-b48b-921da1b0679b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div[2]/ul/li[6]/a</value>
      <webElementGuid>96e5bdf6-1ce8-4356-8d62-23ab70c659a9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/department/6/bcom-computer-application' and (text() = 'BCOM-COMPUTER APPLICATION' or . = 'BCOM-COMPUTER APPLICATION')]</value>
      <webElementGuid>eea5262b-7cd4-463e-b166-f89e1ada7a21</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
