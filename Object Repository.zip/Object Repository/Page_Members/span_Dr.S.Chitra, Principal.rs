<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Dr.S.Chitra, Principal</name>
   <tag></tag>
   <elementGuidId>127a0c54-e015-4254-b876-3b972f6c650a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/table/tbody/tr/td[2]/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>td:nth-of-type(2) > span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Dr.S.Chitra, Principal&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>893cdef5-3195-44e6-add7-ed0130cf1037</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Dr.S.Chitra, Principal</value>
      <webElementGuid>c6f66859-d26e-4581-97ca-3ce79f6664cb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/section[2]/div[@class=&quot;container com-sp pad-bot-70 pg-inn ps_min_height px-5&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[1]/table[1]/tbody[1]/tr[1]/td[2]/span[1]</value>
      <webElementGuid>d2c6ef2f-68ca-48a3-9ff4-68d559cb9f78</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/table/tbody/tr/td[2]/span</value>
      <webElementGuid>1faf1bbc-1b38-4b2c-b65e-370235b9c480</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Chairperson'])[1]/following::span[1]</value>
      <webElementGuid>0c5d2207-9913-4c25-8f25-8100e6d60fe1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Internal Quality Assurance Cell - Members'])[1]/following::span[2]</value>
      <webElementGuid>2cba10e7-af9e-425a-ae2e-3bc70a83b1b2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Director of IQAC'])[1]/preceding::span[1]</value>
      <webElementGuid>4d525094-a2ff-4947-9ea4-a0dd429db0bf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Dr.A.Saranya, Vice Principal'])[1]/preceding::span[1]</value>
      <webElementGuid>583c919d-1f50-4c0d-9729-b097b38f79c2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Dr.S.Chitra, Principal']/parent::*</value>
      <webElementGuid>9921f89f-ea43-4978-971f-005378159dcc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//td[2]/span</value>
      <webElementGuid>bc7faf0d-6927-41a8-b04f-82624c4e7f58</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Dr.S.Chitra, Principal' or . = 'Dr.S.Chitra, Principal')]</value>
      <webElementGuid>48194f00-75fc-4363-aec1-dd5132a430c4</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
