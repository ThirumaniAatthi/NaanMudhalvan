<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Programme  Course Outcomes</name>
   <tag></tag>
   <elementGuidId>0b0f2d07-73b4-40ea-95ef-57991dba622d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//nav[@id='navbar']/ul/li[5]/ul/li/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Programme &amp; Course Outcomes&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>33f6b776-d716-49cb-8d93-1c7fe07aaa7f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/programme-and-course-outcomes</value>
      <webElementGuid>ab62d20d-ec03-4841-8d72-078c70aa9c5a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Programme &amp; Course Outcomes</value>
      <webElementGuid>45429efe-af51-4d88-bbd8-b155c5d5be7d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;navbar&quot;)/ul[@class=&quot;top__menu ms-auto me-auto&quot;]/li[@class=&quot;dropdown&quot;]/ul[1]/li[1]/a[1]</value>
      <webElementGuid>5f42ae5d-db47-467b-bd18-d742d89e528c</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//nav[@id='navbar']/ul/li[5]/ul/li/a</value>
      <webElementGuid>da704c8d-1237-425b-a726-f0741770ffc1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Programme &amp; Course Outcomes')]</value>
      <webElementGuid>07419d43-d8fd-4d36-ad2f-834e72c1816f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Academics'])[1]/following::a[1]</value>
      <webElementGuid>05640642-88d2-4ed0-a7c4-74f57cf1717c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Online Fee Payment'])[1]/following::a[2]</value>
      <webElementGuid>5f612887-8dd3-439c-8a24-82407c289495</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Syllabus'])[1]/preceding::a[1]</value>
      <webElementGuid>fc3cca49-2e36-4231-8991-a614fe4cf521</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Departments'])[1]/preceding::a[2]</value>
      <webElementGuid>9f322eec-fcb2-4102-b8d7-cbb96bd4d07e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Programme &amp; Course Outcomes']/parent::*</value>
      <webElementGuid>44b982c6-0f11-41d0-bf72-f42179cb35f5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/programme-and-course-outcomes')]</value>
      <webElementGuid>0430c365-954b-4cec-b345-086b23a0f9e7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[5]/ul/li/a</value>
      <webElementGuid>221f408c-75b6-485f-b258-53e6e2285b47</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/programme-and-course-outcomes' and (text() = 'Programme &amp; Course Outcomes' or . = 'Programme &amp; Course Outcomes')]</value>
      <webElementGuid>9b76c8db-5bee-4a83-b2f6-3ef3f148121e</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
