<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_NIRF - 2018-2019</name>
   <tag></tag>
   <elementGuidId>fc4bbe8f-62fd-4085-a578-9799f28e94c5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/p[5]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>a[title=&quot;NIRF - 2018-2019&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;NIRF - 2018-2019&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>288a80b9-3b42-48fc-8e0b-620fdbab0762</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://nscollege.org.in/files_list/nscas/fm/WEBSITE/IQAC/NIRF/NIRF-2018-2019.pdf</value>
      <webElementGuid>fb5dd173-b3ef-4c97-86ff-a3543e93327b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>NIRF - 2018-2019</value>
      <webElementGuid>784f5ec9-8b43-4079-bfe7-60b34ffcb511</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>NIRF - 2018-2019</value>
      <webElementGuid>01960a21-9cfe-4c0f-9061-d1aec762f6bd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[4]/section[2]/div[@class=&quot;container com-sp pad-bot-70 pg-inn ps_min_height px-5&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[1]/p[5]/a[1]</value>
      <webElementGuid>a9af8817-434a-429a-a59a-becab19e9be6</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[4]/section[2]/div/div/div/div/p[5]/a</value>
      <webElementGuid>148761e3-f36c-40cc-a3c4-e8c040485833</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'NIRF - 2018-2019')]</value>
      <webElementGuid>07c84b35-a049-4c07-8f10-f0f8407f63c7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='NIRF - 2020-2021'])[1]/following::a[1]</value>
      <webElementGuid>4da8bd09-9b09-469a-9761-dd5d8c91aded</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='NIRF - 2021-2022'])[1]/following::a[2]</value>
      <webElementGuid>ab3d2506-3cf2-4399-a6aa-e243d08e2cf0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Contact'])[2]/preceding::a[1]</value>
      <webElementGuid>829f2ec7-0866-46a2-99fd-94ca99efc00f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='principal@nscollege.org.in'])[1]/preceding::a[6]</value>
      <webElementGuid>6e367c3f-0573-417e-94ce-fbf74b61bfd1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='NIRF - 2018-2019']/parent::*</value>
      <webElementGuid>4359c2a3-6442-4246-b4f6-95a1bf20e731</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://nscollege.org.in/files_list/nscas/fm/WEBSITE/IQAC/NIRF/NIRF-2018-2019.pdf')]</value>
      <webElementGuid>ae1b00be-e526-4551-9916-12f4985d5e30</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p[5]/a</value>
      <webElementGuid>9b8e73fc-9798-4ba2-aadb-88913f2b1b64</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://nscollege.org.in/files_list/nscas/fm/WEBSITE/IQAC/NIRF/NIRF-2018-2019.pdf' and @title = 'NIRF - 2018-2019' and (text() = 'NIRF - 2018-2019' or . = 'NIRF - 2018-2019')]</value>
      <webElementGuid>df806703-f598-4cf8-b8e9-87cb31519a88</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
